<?php
	session_start();
	include_once("connection.class.php");
	$commonObj = new Common();
?>